#include <gtk/gtk.h>




  GtkApplication *app;
  GtkWidget *grid;
  GtkWidget *window;
  GtkWidget *window2;
  GtkWidget *contenedor;
  GtkWidget *contInfoRe;
  GtkWidget *fondo;
  GtkWidget *titulo;
  GtkWidget *ip;
  GtkWidget *puerto;
  GtkWidget *njugador;
  GtkWidget *btnConectar;

  GtkWidget *button1;
  GtkWidget *button2;
  GSList *group;


  void conectar();
